package com.example.secondar;

public class Common {

    public static String model = "model.sfb";
}
